Public domain by Russell Marks.
